
import './App.css';
import Navbar from './Components/Navbar';
import { Cardregistarction } from './Components/Cardregistarction';

function App() {
  return (
    <div >
    <Navbar/>
    <Cardregistarction/>
    </div>
  );
}

export default App;
