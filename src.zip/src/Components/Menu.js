import React from 'react'

const Menu = () => {
  return (
    <div>This is menu content</div>
  )
}

export default Menu